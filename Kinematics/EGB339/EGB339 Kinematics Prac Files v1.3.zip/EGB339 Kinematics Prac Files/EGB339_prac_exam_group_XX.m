%% Solution for EGB339 prac for 2020




function [init_xy, dest_xy] = EGB339_prac_exam_group_XX(dobot_sim, init_positions, dest_positions, use_vision)


    dobot = mdl_Dobot();
    
    if use_vision == true
        
        
        % do computer vision on initial_positions and destination_positions arguments which are images
        
        % add your code here which should include move robot arm and capture image from sim %%
           
        % you will need to calculate the xy positions and return them at the end of this section of code
        % shapes_xy needs to be 
        % init_shape_xy and dest_xy need to be of size 3 x 2 and an example is shown below
        init_xy = [0,0; 0,0; 0,0];
        dest_xy = [0,0; 0,0; 0,0];
        
        
    else

        %% Execute Pick and Place

        % This section iterates through each start and end coordinates
        % to pick up each object and place at the desired location

        
    end
    

end