
% USAGE:
% In order to automate the marking we require this function template
% Please do not modify structure of this function but add your own code
% group_XX should also be changed to the number of your group
% The image_flag will indicate whether the init_positions & dest_positions argument is in the format 
% of an image or whether it has be called and xy (3 x 2 matrix) coordinates have been passed in

function [init_xy, dest_xy] = EGB339_prac_exam_group_XX(init_positions, dest_positions, use_vision)

    if use_vision == true
        % do computer vision on initial_positions and destination_positions arguments which are images
        
        % add your code here which should include move robot arm and capture image from sim %%
           
        % you will need to calculate the xy positions and return them at the end of this section of code
        % shapes_xy needs to be 
        % init_shape_xy and dest_xy need to be of size 3 x 2 and an example is shown below
        init_xy = [0,0; 0,0; 0,0];
        dest_xy = [0,0; 0,0; 0,0];
        
    %If using vision the function will be called twice and on the second time will enter this section    
    else
        
        % init_positions and dest_positions are x,y coordinates
        
        % add your robot pick and place code here using init_positions and dest_positions%%
        
    end
        

end